socket_host = "localhost"
socket_port = 8402
mysql_host = 'localhost'
mysql_port = 3306
mysql_user = 'root'
mysql_password = 'kai199418'
mysql_database = 'recruitment'