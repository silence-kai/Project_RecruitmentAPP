# RecruitmentAPP
Use Tkinter, Socket, Process simulated recruitment, login interface, chat interface, Mysql interface, etc

This is a project for simulate the function of a recruitment APP，include sign in and sign up, chat with HR, up and download resume, Find the job by needs and conditions.
